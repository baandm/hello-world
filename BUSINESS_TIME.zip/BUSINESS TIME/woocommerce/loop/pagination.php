<div align="left">
<span id="nextt"><?php next_posts_link('&larr; Следующая') ?></span></div>

<div align="right">
<span id="nextt"><?php previous_posts_link('Предыдущая &rarr;') ?>
</span>  </div>